# Estate Levels — the vertical level ladder (Progress screen)

This folder is everything needed to recreate the screen exactly.

## Files
- `Estate Levels.dc.html` — the complete screen source. Read this first; it IS the design.
    - the template (markup) sits between <x-dc> … </x-dc>; every style is inline, colours are var(--*) tokens
    - the logic is the `class Component` in the <script data-dc-script> at the end (levels data, scroll-snap, rail, sheet)
    - each level's isometric drawing is an inline <svg> in the template (Plot / Grading / Foundation / Steel Frame / Villa)
- `styles.css` — the design tokens (:root variables) the template references. Copy the :root block into your app.
- `Estate Levels (standalone).html` — a bundled, runnable copy for visual reference. Open in a browser; don't edit.

## Screen anatomy (top → bottom, one 402×874 phone)
1. Header: chevron-down button (left) · kicker YOUR ESTATE + "Level 5" · right pill "● SIP ₹25,000/mo"
2. Left rail: a vertical accent track (--color-accent) with hollow ticks per level and a filled dot at the current level;
   rupee labels (₹0, ₹1L, ₹2L …) sit right of the dots at their thresholds.
3. Scroll-snap stack of level cards, LOWEST level at the bottom, scrolled up to the current level. Each card:
     - isometric tile drawing (≈ 300px wide), floating above a dark plinth
     - title in 44px Inter 500 with a soft glow ("The Plot", "Foundation" …)
     - LEVEL pill: rounded-8px, --color-section deep indigo, gold numeral coin left, gold "₹ amount" right
     - one-line description in --color-neutral-300
     - "FUND UNLOCKS" kicker, then 5 fund tiles laid 3 + 2: icon · name · rupee amount · thin progress bar + %
       (Arbitrage 36% · Gold 16% · Large 16% · Mid 16% · Small 16% of that level's cumulative amount)
     - a faint "^ LEVEL n · NAME" caption between cards
4. Level thresholds: L1 Plot ₹1,00,000 · L2 Levelled Ground ₹2,00,000 · L3 Foundation ₹3,00,000 · L4 Steel Frame ₹4,00,000 · L5 Villa ₹35,00,000

## Rules the agent must keep
- Inter only, heading weight 500. No pure black/white — all colours from the token ramps.
- Accent is used as a line and a glow, never as a flood; only the LEVEL pill and the deck section ground use --color-section.
- Isometric tiles: half-width 93.6 / half-height 54 ratio; drawings are SVG polygons, no images.
- Ruppee formatting is Indian (₹1,00,000 not ₹100,000).
