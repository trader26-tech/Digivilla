# Home — "Sanjeev's City" estate board

Everything needed to recreate the Home screen exactly.

## Files
- `sanjeevs-city-template.html` — the complete app source, plain HTML/CSS/JS, no framework. Home is the default tab.
    - Home markup: search  id="tabHome"
    - Estate board: the <svg> inside #tabHome — tiles are <g class="cell" data-state=…> placed with <use href="#tVilla|#tBuild|#tLand|#tLocked">
    - Tile symbols: the <defs> block (#tLocked #tLand #tVilla #tBuild) — pure SVG polygons, no images
    - Coin, tap-to-collect, cell tap sheets, disclaimer sheet: the inline <script> at the end
    - Colours/spacing: all var(--*) from :root at the top of the <style>
- `Home Screen (standalone).html` — bundled runnable copy (fonts inlined). Open in a browser for visual reference; don't edit.

## Screen anatomy (402×874 phone, dark ground #161826)
1. Header, two halves split by a faint vertical rule fading at its ends:
     LEFT  — gold ↓ coin icon · WITHDRAWALS kicker · ₹42,000 /mo in gold (--gold ramp) · "4 villas · SWP on the 1st"
     RIGHT — INVESTMENTS kicker · ↑ accent icon · ₹35,000 /mo in accent-200 · "1 build · SIP on the 5th"
   Numbers 34px Inter 500, "/mo" 13px neutral-400.
2. Centre: kicker YOUR ESTATE (10px, .14em tracking, neutral-400) · title "Sanjeev's City" 34px Inter 500.
3. Estate board: 3×3 isometric grid. Placement formula per cell (col,row ∈ 0..2):
     offsetX = (col − row) × 93.6 ;  offsetY = (col + row) × 54 ;  paint in ascending (col + row)
   States: villa (cream house, pool, hedge, fence) · build (steel frame + crane, animated) · land (bare turf) · locked (dashed dark diamond).
   A gold ₹ coin bobs above one villa on payout day; tapping it plays a fly-to-header animation and adds to withdrawals.
   Owned land is one continuous green block with a soft accent glow under it; open tiles are dashed.
   Every tile is tappable → a bottom sheet (villa details / build level / start-a-build for locked).
4. Portfolio block: kicker PORTFOLIO VALUE · ₹1,70,63,583 at 48px · "Invested ₹1,55,00,000 • +10.1% returns" (returns in the green ramp)
   · a 5-segment allocation bar (arbitrage grey-teal, gold, three greens) · five columns ₹ value + fund name in the segment's colour.
5. "What do Villa and Plot mean? ›" link → disclaimer sheet (Villa = arbitrage + equity mix; Plot = pure equity; units at NAV, in your own name).
6. Tab bar: Explore (compass) · Home (house, active, accent) · Progress (bars). 10px .08em labels.

## Rules
- Inter only, weight 500 for headings; sizes carry hierarchy, never bold.
- No pure black/white; every colour from the :root ramps. Accent (#9184d9) as lines, glows and the active tab — never as a fill.
- Indian rupee grouping (₹1,70,63,583). Label the income "withdrawals", never "rent earned".
- SVG has no z-buffer: emit cells sorted by (col + row) or front tiles paint behind back ones.
